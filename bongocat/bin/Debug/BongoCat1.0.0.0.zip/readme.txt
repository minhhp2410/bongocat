Ấn F1 để tắt/bật nền + khung form
F2 để cho app luôn on-top
sửa nội dung file mode.txt theo tên folder con của imgs để đổi assests
.net framework 4.7.2